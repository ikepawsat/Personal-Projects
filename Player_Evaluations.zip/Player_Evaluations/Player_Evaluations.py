#Author: Ike Pawsat - ike.pawsat@gmail.com
#WAR data from: https://www.baseballprospectus.com/leaderboards/hitting/
#Honestly, this only considers what I would pay each player for each win basically.
#This is a base salary excluding money you can get from other form of monetization.
#More just me messing around organizing and using large data sets.

import pandas as pd

# List of file names from ^^
file_names = ['WAR_2021.csv', 'WAR_2022.csv', 'WAR_2023.csv']

total_warp = 0
total_weighted_warp = 0
dfs = []
cost_per_win = 3650063.23  # total mlb player salaries / # of regular season wins (1215)

pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)

for file_name in file_names:
    df = pd.read_csv(file_name)
    if 'Name' in df.columns and 'WARP' in df.columns:
        df['Weighted_WARP'] = df.apply(lambda row: (
            0.31 * row['WARP'] +
            0.33 * row['WARP'] +
            0.36 * row['WARP']
        ), axis=1)

        # Calculate cost
        df['Cost'] = df['Weighted_WARP'] * cost_per_win

        dfs.append(df[['Name', 'Weighted_WARP', 'Cost']])

        # Accumulate total WARP and Weighted_WARP
        total_warp += df.groupby('Name')['WARP'].sum()
        total_weighted_warp += df.groupby('Name')['Weighted_WARP'].sum()
    else:
        print(f"One or more columns (Name, WARP) not found in {file_name}.")

# Calculate the average WARP and Weighted_WARP
average_warp = total_warp / len(file_names)
average_weighted_warp = total_weighted_warp / len(file_names)

# Create a new DataFrame with averaged values, excluding players with missing data
averaged_df = pd.DataFrame({
    'Name': average_warp.index,
    'Average_WARP': average_warp.values,
    'Average_Weighted_WARP': average_weighted_warp.values,
    'Average_Cost': average_weighted_warp.values * cost_per_win
}).dropna()

# Filter for players with either positive average WARP or positive average Weighted_WARP
positive_avg_warp_df = averaged_df[(averaged_df['Average_WARP'] > 0) | (averaged_df['Average_Weighted_WARP'] > 0)]
pd.set_option('display.float_format', lambda x: '%.2f' % x)
print(f"\nFinal List of Players with Positive Average WARP or Positive Average Weighted_WARP:\n")
print(positive_avg_warp_df)